# Spesifikasi Teknis, Desain, dan Flow Sistem
## SIMPINJAM — Sistem Informasi Peminjaman & Penyewaan Aset Kampus

Dokumen ini adalah pendalaman teknis dari dokumen *Rencana Implementasi* sebelumnya, mencakup: (1) Kebutuhan Fungsional & Non-Fungsional, (2) Arsitektur Sistem, (3) Desain Basis Data (ERD konseptual), dan (4) Flow proses bisnis end-to-end.

---

## BAGIAN A — KEBUTUHAN FUNGSIONAL (Functional Requirements)

Ditulis dalam format: **Kode | Aktor | Kebutuhan | Kriteria Penerimaan**

### A.1 Modul Master Data

| Kode | Aktor | Kebutuhan | Kriteria Penerimaan |
|---|---|---|---|
| FR-01 | Admin Pusat | Mengelola Kategori Aset (Kendaraan, Ruangan, Alat, Fasilitas) beserta atribut dinamis per kategori | Sistem dapat menyimpan atribut berbeda per kategori (mis. kendaraan: plat nomor, kapasitas; ruangan: kapasitas kursi, fasilitas AC/proyektor) tanpa ubah struktur tabel inti |
| FR-02 | Admin Unit | Mendaftarkan Data Aset baru lengkap dengan foto, lokasi, unit pemilik, dan status awal | Aset tersimpan dengan kode unik & QR code otomatis dibuat |
| FR-03 | Admin Pusat | Mengelola data Fakultas/Unit dan Lokasi/Gedung | Struktur hierarki (Fakultas → Unit → Lokasi) dapat direpresentasikan |
| FR-04 | Admin Unit | Mengelola data Peminjam (Mahasiswa/Dosen/Staf/Eksternal) | Validasi NIM/NIP unik, data eksternal wajib KTP/institusi asal |
| FR-05 | Admin Pusat | Mengelola Jenis Pembayaran (untuk skema sewa) | Tersedia minimal: tunai, transfer, QRIS |

### A.2 Modul Pengajuan & Approval

| Kode | Aktor | Kebutuhan | Kriteria Penerimaan |
|---|---|---|---|
| FR-06 | Peminjam | Mengajukan peminjaman/penyewaan aset dengan memilih tanggal & jam via kalender ketersediaan | Sistem menolak pengajuan jika slot bentrok dengan booking lain yang sudah disetujui |
| FR-07 | Peminjam | Melihat status pengajuan secara real-time | Status: Diajukan → Menunggu Approval → Disetujui/Ditolak → Serah Terima → Dipinjam → Dikembalikan |
| FR-08 | Approver (Kaprodi/Kepala Unit) | Menyetujui/menolak pengajuan yang masuk ke unitnya, dengan catatan alasan | Approval tercatat dengan timestamp & nama approver (audit trail) |
| FR-09 | Sistem | Mendukung approval berjenjang (multi-level) sesuai kebijakan per unit | Level approval dapat dikonfigurasi per kategori aset/unit tanpa ubah kode program |
| FR-10 | Sistem | Memasukkan pengajuan ke antrian (waiting list) otomatis jika aset sedang dipakai | Peminjam mendapat notifikasi saat aset tersedia dan statusnya berubah otomatis |
| FR-11 | Sistem | Memprioritaskan kegiatan akademik dibanding non-akademik saat ada konflik jadwal | Sistem menampilkan peringatan konflik dan opsi override hanya untuk role tertentu |
| FR-12 | Peminjam/Admin | Membuat pengajuan berulang/batch (recurring booking) untuk kebutuhan rutin semesteran | Satu pengajuan dapat menghasilkan banyak slot booking otomatis sesuai pola berulang |

### A.3 Modul Serah Terima & Pengembalian

| Kode | Aktor | Kebutuhan | Kriteria Penerimaan |
|---|---|---|---|
| FR-13 | Petugas | Melakukan serah terima aset dengan checklist kondisi & foto | Checklist wajib diisi sebelum status berubah menjadi "Dipinjam" |
| FR-14 | Petugas | Memindai QR code aset saat serah terima/pengembalian | Waktu proses tercatat otomatis, mengurangi input manual |
| FR-15 | Petugas/Peminjam | Membubuhkan tanda tangan digital pada dokumen serah terima & pengembalian | Dokumen serah terima otomatis ter-generate sebagai PDF dengan tanda tangan |
| FR-16 | Sistem | Menghitung keterlambatan pengembalian secara otomatis | Denda (uang atau penangguhan hak pinjam) dihitung berdasarkan aturan per kategori aset |
| FR-17 | Sistem | Menangguhkan otomatis hak pinjam peminjam yang berulang kali telat/merusak aset | Ambang batas pelanggaran dapat dikonfigurasi oleh Admin Pusat |

### A.4 Modul Penyewaan & Keuangan (Aktif hanya untuk transaksi berbayar)

| Kode | Aktor | Kebutuhan | Kriteria Penerimaan |
|---|---|---|---|
| FR-18 | Bagian Keuangan | Mencatat piutang dan pembayaran penyewaan | Status piutang: Belum Lunas / Lunas Sebagian / Lunas |
| FR-19 | Bagian Keuangan | Mengelola deposit/jaminan untuk aset bernilai tinggi | Deposit otomatis masuk sebagai kas masuk terpisah dari pendapatan sewa |
| FR-20 | Bagian Keuangan | Mencatat transaksi akuntansi (CoA, jurnal umum, neraca, tutup buku) | Modul ini dapat dinonaktifkan penuh untuk unit yang hanya melayani peminjaman gratis |

### A.5 Modul Pemeliharaan Aset

| Kode | Aktor | Kebutuhan | Kriteria Penerimaan |
|---|---|---|---|
| FR-21 | Admin Unit | Menjadwalkan pemeliharaan rutin aset (servis kendaraan, kalibrasi alat) | Aset otomatis berstatus "Maintenance" dan tidak bisa dipinjam selama periode tsb |
| FR-22 | Admin Unit | Mencatat riwayat perbaikan & biaya pemeliharaan | Riwayat dapat difilter per aset/kategori/periode |

### A.6 Modul Notifikasi

| Kode | Aktor | Kebutuhan | Kriteria Penerimaan |
|---|---|---|---|
| FR-23 | Sistem | Mengirim notifikasi WhatsApp/Email untuk: pengajuan baru ke approver, status disetujui/ditolak ke peminjam, reminder H-1 sebelum jadwal, reminder pengembalian | Notifikasi terkirim maksimal dalam 1 menit setelah trigger event |

### A.7 Modul Laporan & Statistik

| Kode | Aktor | Kebutuhan | Kriteria Penerimaan |
|---|---|---|---|
| FR-24 | Manajemen/Admin | Melihat dashboard utilisasi aset real-time | Menampilkan: total aset, aset tersedia/dipinjam/maintenance, tren peminjaman, aset paling sering dipinjam |
| FR-25 | Manajemen | Mengekspor laporan (rekap/detail peminjaman, keuangan, keterlambatan) ke PDF/Excel | Laporan dapat difilter per kategori, unit, dan rentang tanggal |
| FR-26 | Peminjam | Memberi rating/feedback kondisi aset pasca pemakaian | Rating tersimpan dan tampil di riwayat aset untuk referensi admin |

### A.8 Modul Keamanan & Administrasi

| Kode | Aktor | Kebutuhan | Kriteria Penerimaan |
|---|---|---|---|
| FR-27 | Admin Pusat | Mengelola user & role (RBAC) | Role: Super Admin, Admin Unit, Approver, Petugas, Peminjam, Keuangan |
| FR-28 | Sistem | Mencatat audit trail seluruh aksi penting (create/update/approve/reject) | Log mencakup siapa, apa, kapan, dan tidak dapat dihapus oleh user biasa |
| FR-29 | Sistem | Menyediakan API terbuka untuk integrasi eksternal (SIAKAD, SSO, SIMAK-BMN) | API terdokumentasi (mis. via Swagger/OpenAPI) dan menggunakan autentikasi token |

---

## BAGIAN B — KEBUTUHAN NON-FUNGSIONAL (Non-Functional Requirements)

| Kategori | Kebutuhan |
|---|---|
| **Performa** | Waktu respons halaman < 2 detik untuk operasi umum; pencarian ketersediaan aset < 1 detik untuk katalog hingga ~10.000 aset |
| **Skalabilitas** | Arsitektur mendukung penambahan unit/fakultas baru tanpa downtime; desain multi-tenant di level data (unit_id sebagai partition key) |
| **Keamanan** | Enkripsi data sensitif (password, data pribadi) at-rest & in-transit (HTTPS/TLS); autentikasi berbasis token (JWT) dengan expiry; rate-limiting API |
| **Kepatuhan** | Mematuhi UU PDP untuk data pribadi (NIM, NIP, no. HP, KTP eksternal); kebijakan retensi & penghapusan data |
| **Ketersediaan** | Target uptime 99% (di luar maintenance terjadwal); backup harian otomatis + disaster recovery plan |
| **Usability** | Desain mobile-first/responsif; alur pengajuan maksimal 5 langkah; dukungan Bahasa Indonesia penuh |
| **Maintainability** | Kode modular per domain (asset, request, approval, finance); dokumentasi API & basis data terpusat |
| **Auditability** | Semua transaksi memiliki log immutable (tidak bisa diedit/dihapus, hanya bisa ditambah entri koreksi) |
| **Interoperabilitas** | Format ekspor data kompatibel dengan kebutuhan pelaporan SIMAK-BMN (jika kampus negeri) |

---

## BAGIAN C — ARSITEKTUR SISTEM

### C.1 Arsitektur Tingkat Tinggi (3-Tier)

```
[ Klien ]                     [ Aplikasi/API ]                  [ Data ]
 - Web (Admin/Approver)  <-->   - REST/GraphQL API        <-->   - Database utama (relasional)
 - Web Responsif/PWA           - Modul Auth (JWT/SSO)            - Object storage (foto, PDF)
   (Peminjam)                  - Modul Notifikasi (WA/Email)     - Cache (Redis) untuk kalender
 - Mobile (opsional)           - Job Scheduler (reminder,           ketersediaan
                                  denda otomatis, blacklist)
                                - Modul Integrasi (SIMAK-BMN,
                                  SIAKAD, SSO Kampus)
```

### C.2 Rekomendasi Tumpukan Teknologi (Tech Stack)

| Layer | Opsi Rekomendasi | Catatan |
|---|---|---|
| Frontend Web | React/Vue.js + Tailwind CSS | Komponen kalender ketersediaan sebagai modul reusable |
| Mobile/PWA | Progressive Web App (bukan native dulu) | Fase awal cukup PWA agar hemat biaya pengembangan |
| Backend/API | Laravel (PHP) atau Node.js (NestJS) | Laravel unggul di ekosistem lokal Indonesia (banyak talent), NestJS unggul di skalabilitas |
| Database | PostgreSQL atau MySQL | PostgreSQL lebih unggul untuk fitur constraint & concurrency booking |
| Cache/Queue | Redis | Untuk validasi bentrok jadwal secara cepat & antrian notifikasi |
| Notifikasi | WhatsApp Business API / Fonnte / Wablas, SMTP untuk email | Sesuaikan dengan anggaran & volume notifikasi |
| Penyimpanan File | Object storage (S3-compatible/local) | Untuk foto kondisi aset & dokumen serah terima |
| Hosting | On-premise server kampus atau cloud (VPS) | Pertimbangkan kebijakan data internal kampus |

### C.3 Komponen Sistem Utama

1. **Auth Service** — login, SSO kampus (opsional), role & permission
2. **Asset Service** — CRUD aset, kategori, status, QR code generation
3. **Booking Service** — validasi ketersediaan, kalender, antrian (waiting list), booking berulang
4. **Approval Service** — workflow approval berjenjang, konfigurasi level per unit
5. **Transaction Service** — serah terima, pengembalian, denda, deposit
6. **Finance Service** — piutang, pembayaran, akuntansi (modul opsional)
7. **Maintenance Service** — jadwal & riwayat pemeliharaan aset
8. **Notification Service** — trigger WA/email berbasis event
9. **Reporting Service** — dashboard, ekspor laporan
10. **Audit Service** — pencatatan log semua aksi penting

---

## BAGIAN D — DESAIN BASIS DATA (ERD Konseptual)

Berikut entitas utama beserta field kunci dan relasinya (disederhanakan, siap dikembangkan jadi ERD detail):

### D.1 Entitas Master

- **units** (id, nama_unit, parent_unit_id, jenis_unit)
- **locations** (id, nama_lokasi, gedung, lantai, unit_id)
- **asset_categories** (id, nama_kategori) — Kendaraan / Ruangan / Alat / Fasilitas
- **asset_types** (id, category_id, nama_tipe, atribut_dinamis JSON)
- **assets** (id, kode_aset, type_id, unit_id, location_id, status, kondisi, qr_code, foto, tarif_sewa nullable)
- **borrowers** (id, jenis: mahasiswa/dosen/staf/eksternal, nama, nim_nip nullable, unit_id nullable, no_hp, email, status_blacklist)
- **operators** (id, nama, jenis_keahlian) — sopir/teknisi pendamping

### D.2 Entitas Transaksi

- **requests** (id, borrower_id, asset_id, tanggal_mulai, tanggal_selesai, jenis: peminjaman/penyewaan, status, recurring_group_id nullable, prioritas)
- **approvals** (id, request_id, approver_id, level, status, catatan, timestamp)
- **waiting_list** (id, request_id, asset_id, urutan, status)
- **handovers** (id, request_id, kondisi_checklist JSON, foto, tanda_tangan, waktu, petugas_id)
- **returns** (id, request_id, kondisi_checklist JSON, foto, tanda_tangan, waktu, terlambat_menit, denda)
- **maintenance_logs** (id, asset_id, jenis_pemeliharaan, tanggal_mulai, tanggal_selesai, biaya, keterangan)
- **ratings** (id, request_id, borrower_id, skor, komentar)

### D.3 Entitas Keuangan (aktif jika ada penyewaan)

- **payment_types** (id, nama)
- **invoices** (id, request_id, jumlah_tagihan, status, jatuh_tempo)
- **payments** (id, invoice_id, jumlah_bayar, payment_type_id, tanggal)
- **deposits** (id, request_id, jumlah, status: masuk/keluar)
- **chart_of_accounts** (id, kode_akun, nama_akun, tipe)
- **journal_entries** (id, tanggal, akun_debit, akun_kredit, jumlah, keterangan)

### D.4 Entitas Sistem

- **users** (id, nama, email, password_hash, role_id)
- **roles** (id, nama_role) — Super Admin, Admin Unit, Approver, Petugas, Peminjam, Keuangan
- **permissions** (id, role_id, module, action)
- **notifications_log** (id, user_id/borrower_id, channel, isi, status_kirim, waktu)
- **audit_logs** (id, user_id, aksi, modul, data_sebelum, data_sesudah, waktu)

### D.5 Relasi Kunci

- `requests` → `assets` (1 aset per request; recurring_group_id menghubungkan banyak requests dari satu pengajuan berulang)
- `requests` → `approvals` (1 request bisa punya banyak baris approval sesuai jumlah level)
- `requests` → `handovers` → `returns` (alur linear satu request)
- `requests` → `invoices` → `payments` (hanya untuk jenis = penyewaan)
- `assets` → `maintenance_logs` (riwayat pemeliharaan per aset)

---

## BAGIAN E — FLOW PROSES BISNIS (End-to-End)

### E.1 Flow Peminjaman Internal (Gratis)

1. Peminjam login → pilih kategori aset → cek kalender ketersediaan
2. Peminjam mengisi form pengajuan (tanggal, jam, tujuan penggunaan)
3. Sistem validasi: cek bentrok jadwal → jika bentrok & tidak ada prioritas lebih tinggi → tawarkan slot alternatif atau masuk waiting list
4. Jika slot tersedia → status: **"Menunggu Approval"** → notifikasi terkirim ke Approver
5. Approver meninjau → **Setujui** atau **Tolak** (dengan catatan)
   - Jika level approval > 1 → lanjut ke approver berikutnya
6. Jika disetujui semua level → status: **"Disetujui"** → notifikasi ke peminjam
7. Pada hari-H → Petugas melakukan **serah terima** (scan QR, checklist kondisi, foto, tanda tangan digital) → status: **"Dipinjam"**
8. Setelah selesai pakai → peminjam/petugas melakukan **pengembalian** (checklist kondisi, foto)
9. Sistem cek waktu pengembalian:
   - Tepat waktu → status **"Selesai"**
   - Terlambat → hitung durasi keterlambatan → terapkan sanksi (penangguhan sementara atau catatan pelanggaran)
10. Peminjam memberi **rating/feedback** kondisi aset (opsional)
11. Data tercatat di laporan utilisasi & audit trail

### E.2 Flow Penyewaan Berbayar

1–6. *(Sama seperti flow peminjaman di atas)*

7. Setelah disetujui → sistem generate **invoice/tagihan** otomatis berdasarkan tarif sewa & durasi
8. Peminjam melakukan pembayaran (tunai/transfer/QRIS) → dicatat oleh Bagian Keuangan
9. Jika ada **deposit/jaminan** → dicatat terpisah sebagai kas masuk sementara
10. Setelah pembayaran lunas (atau DP sesuai kebijakan) → lanjut ke **serah terima** seperti flow di atas
11. Setelah **pengembalian**:
    - Jika ada kerusakan → potong dari deposit, catat sebagai pendapatan lain-lain
    - Jika tidak ada masalah → deposit dikembalikan penuh
12. Transaksi tercatat ke jurnal umum & laporan keuangan

### E.3 Flow Approval Berjenjang (Detail)

```
Pengajuan Masuk
      │
      ▼
Level 1: Admin Unit/Kepala Ruangan
  ├── Ditolak → Selesai (notifikasi ke peminjam)
  └── Disetujui
        │
        ▼
Level 2 (jika dikonfigurasi): Kaprodi/Kepala Unit
  ├── Ditolak → Selesai (notifikasi ke peminjam)
  └── Disetujui
        │
        ▼
Level 3 (opsional, aset khusus/bernilai tinggi): Bagian Rumah Tangga/BMN
  ├── Ditolak → Selesai
  └── Disetujui → Status Final: DISETUJUI
```
*Jumlah level dapat dikonfigurasi per kategori aset atau per unit (mis. ruang kelas cukup 1 level, kendaraan dinas butuh 2–3 level).*

### E.4 Flow Antrian (Waiting List)

1. Peminjam mengajukan pada slot yang sedang terisi
2. Sistem otomatis memasukkan ke **waiting_list** dengan urutan FIFO (atau prioritas akademik)
3. Jika pengajuan di depannya dibatalkan/ditolak → sistem otomatis menawarkan slot ke antrian berikutnya
4. Peminjam menerima notifikasi & diberi batas waktu konfirmasi (mis. 1x24 jam) sebelum ditawarkan ke antrian berikutnya

### E.5 Flow Penangguhan Otomatis (Blacklist)

1. Sistem memantau jumlah pelanggaran per peminjam (telat kembali / merusak aset)
2. Jika melewati ambang batas (dikonfigurasi Admin Pusat, mis. 3x pelanggaran dalam 6 bulan)
3. Sistem otomatis mengubah status peminjam menjadi **"Ditangguhkan"** selama periode tertentu
4. Peminjam tidak bisa mengajukan pengajuan baru selama status ini aktif
5. Admin Pusat dapat melakukan override manual jika diperlukan (dengan catatan alasan, tercatat di audit trail)

### E.6 Flow Pemeliharaan Aset

1. Admin Unit menjadwalkan pemeliharaan (rutin atau insidental akibat kerusakan saat pengembalian)
2. Aset otomatis berubah status menjadi **"Maintenance"** — tidak muncul di hasil pencarian ketersediaan
3. Setelah pemeliharaan selesai → Admin Unit update riwayat (biaya, keterangan) → status kembali **"Tersedia"**

---

## BAGIAN F — DESAIN UI/UX (Overview)

### F.1 Prinsip Desain

- **Mobile-first**: mayoritas peminjam (mahasiswa/dosen) akan mengakses dari HP
- **Role-based dashboard**: tampilan berbeda sesuai role (Peminjam vs Approver vs Admin vs Keuangan)
- **Status berkode warna**: mis. hijau (disetujui/tersedia), kuning (menunggu approval/maintenance), merah (ditolak/terlambat), abu-abu (selesai)
- **Alur pengajuan maksimal 5 langkah**: Pilih Aset → Pilih Jadwal → Isi Tujuan → Review → Submit

### F.2 Daftar Layar Utama per Role

**Peminjam:**
1. Dashboard ringkas (status pengajuan aktif, riwayat)
2. Katalog Aset (filter kategori, unit, ketersediaan)
3. Kalender Ketersediaan Aset (tampilan mingguan/bulanan)
4. Form Pengajuan Peminjaman/Penyewaan
5. Halaman Status/Tracking Pengajuan (timeline visual)
6. Riwayat & Rating Pasca-Pemakaian

**Approver:**
1. Inbox Approval (daftar pengajuan pending, dengan tombol Setuju/Tolak cepat)
2. Detail Pengajuan (info lengkap peminjam, tujuan, jadwal)
3. Riwayat Approval

**Admin Unit:**
1. Dashboard Utilisasi Aset (grafik ketersediaan, tren peminjaman)
2. Manajemen Aset (CRUD, generate QR code)
3. Manajemen Serah Terima & Pengembalian (checklist digital)
4. Manajemen Pemeliharaan
5. Laporan (ekspor PDF/Excel)

**Bagian Keuangan:**
1. Dashboard Piutang & Kas
2. Invoice & Pembayaran
3. Laporan Keuangan (neraca, jurnal, tutup buku)

**Super Admin:**
1. Manajemen User & Role
2. Konfigurasi Approval Berjenjang per Unit/Kategori
3. Audit Log Viewer
4. Pengaturan Sistem Global

### F.3 Elemen UI Kompleks yang Direkomendasikan

- **Kalender ketersediaan interaktif** (drag-select slot waktu, warna berbeda per status booking)
- **Timeline status pengajuan** (stepper visual: Diajukan → Approval → Disetujui → Serah Terima → Dikembalikan)
- **Checklist kondisi aset dengan upload foto** (before/after, multi-foto per titik pemeriksaan)
- **Widget dashboard**: kartu metrik (total aset, sedang dipinjam, maintenance), grafik tren (line chart peminjaman per bulan), pie chart distribusi kategori aset, tabel top-10 aset paling sering dipinjam
- **Inbox approval dengan aksi cepat** (swipe/one-click approve-reject dari daftar, tanpa perlu buka detail penuh untuk kasus sederhana)

---

## Penutup

Dokumen ini melengkapi *Rencana Implementasi* sebelumnya dengan detail teknis siap pakai sebagai acuan tim pengembang (backend, frontend, database) dan tim business analyst saat melakukan workshop kebutuhan lanjutan dengan pihak kampus. Detail ERD dan flow di atas masih bersifat konseptual dan perlu divalidasi ulang saat sesi requirement gathering dengan pemangku kepentingan kampus (bagian rumah tangga, keuangan, dan fakultas percontohan).