# Rencana Implementasi Sistem Manajemen Peminjaman & Penyewaan Aset Kampus
### (Generalisasi dari Model Sistem "StarentCar")

---

## 1. Ringkasan Eksekutif

Dokumen ini merupakan rencana implementasi untuk membangun sistem yang **mengadopsi arsitektur dan pola fungsional StarentCar** (rental mobil), namun **digeneralisasi** agar dapat menangani:

- **Peminjaman** (tanpa biaya, untuk civitas akademika internal — mahasiswa, dosen, staf, unit/fakultas)
- **Penyewaan** (berbayar, bisa untuk internal maupun pihak eksternal/umum)
- **Jenis objek yang lebih luas**, bukan hanya kendaraan, tapi juga:
  - Ruangan (aula, ruang kelas, ruang rapat, ruang sidang, lab)
  - Aset bergerak (proyektor, sound system, kamera, laptop, alat laboratorium, kendaraan operasional kampus)
  - Fasilitas lain (lapangan olahraga, gedung serbaguna, dsb.)

Nama kerja sistem pada dokumen ini: **SIMPINJAM** (Sistem Informasi Peminjaman & Penyewaan Aset Kampus) — dapat diganti sesuai kebutuhan.

---

## 2. Pemetaan Konsep: StarentCar → SIMPINJAM

Prinsipnya, hampir semua modul StarentCar tetap relevan, hanya **objek transaksinya digeneralisasi** dari "Mobil" menjadi "Aset" (dengan kategori/tipe apa pun), dan ditambah beberapa modul baru yang spesifik untuk konteks kampus (approval berjenjang, kalender ketersediaan, dan pembedaan skema gratis vs berbayar).

| Modul StarentCar (Rental Mobil) | Modul SIMPINJAM (Kampus) | Perubahan Utama |
|---|---|---|
| Master: Tipe Mobil, Merek, Warna, Status Mobil, Mobil | Master: **Kategori Aset**, **Jenis Aset**, **Data Aset** (kendaraan/ruangan/alat/fasilitas) | Digeneralisasi dari kendaraan → semua jenis aset, dengan atribut dinamis per kategori |
| Master: Customer Pribadi / Corporate | Master: **Peminjam** — dibagi jadi Mahasiswa, Dosen/Staf, Unit/Fakultas Internal, Eksternal/Umum | Ditambah validasi NIM/NIP/unit kerja |
| Master: Sopir | Master: **Petugas/Operator Pendamping** (jika ada aset yang butuh operator, mis. sopir kendaraan dinas, teknisi alat lab) | Tetap relevan |
| Master: Kota, Cabang | Master: **Lokasi/Gedung**, **Fakultas/Unit Pemilik Aset** | Disesuaikan struktur organisasi kampus |
| Transaksi: Sewa Pribadi/Corporate | Transaksi: **Pengajuan Peminjaman** & **Pengajuan Penyewaan** | Ditambah alur **approval berjenjang** (baru, tidak ada di rental mobil) |
| Transaksi: Serah Terima | Transaksi: **Serah Terima Aset** | Ditambah checklist kondisi aset (foto sebelum/sesudah) |
| Transaksi: Kembali Mobil | Transaksi: **Pengembalian Aset** | Ditambah kalkulasi keterlambatan otomatis & denda |
| Transaksi: Piutang & Bayar Piutang | Transaksi: **Piutang Penyewaan** (hanya berlaku utk transaksi berbayar) | Tidak berlaku untuk peminjaman gratis |
| Deposit | **Deposit/Jaminan** (opsional, untuk aset bernilai tinggi) | Tetap relevan, terutama utk eksternal |
| Service Mobil | **Pemeliharaan Aset** (servis kendaraan, kalibrasi alat, maintenance ruangan/AC/proyektor) | Digeneralisasi ke semua kategori aset |
| Akuntansi (CoA, Neraca, Jurnal, Tutup Buku) | **Akuntansi** (opsional, aktif hanya jika ada transaksi penyewaan berbayar) | Bisa dinonaktifkan untuk unit yang hanya menangani peminjaman gratis |
| Keuangan (Kas/Bank, Laporan Kas) | **Keuangan** (hanya untuk arus dana penyewaan) | Sama, scoped ke penyewaan |
| Statistik Laporan | **Statistik & Laporan Utilisasi Aset** | Ditambah metrik non-finansial: tingkat utilisasi, aset paling sering dipinjam, unit paling aktif |
| Dashboard | **Dashboard** | Ditambah **kalender ketersediaan aset** dan indikator approval pending |

### Modul Baru yang Tidak Ada di StarentCar (khusus kebutuhan kampus)

1. **Alur Persetujuan (Approval Workflow)** — pengajuan peminjaman/penyewaan harus disetujui oleh pihak berwenang (mis. kaprodi, kepala unit, bagian rumah tangga/BMN) sebelum disetujui, dengan status: Diajukan → Disetujui/Ditolak → Dipinjam → Dikembalikan.
2. **Kalender Ketersediaan (Booking Calendar)** — mencegah bentrok jadwal pemakaian ruangan/aset yang sama pada waktu yang sama (fitur krusial yang tidak dibutuhkan di rental mobil karena skala armadanya berbeda).
3. **Skema Dual: Gratis vs Berbayar** — flag di level transaksi/kategori aset yang menentukan apakah proses lanjut ke modul pembayaran/piutang atau berhenti di serah terima.
4. **Notifikasi Otomatis** (WhatsApp/Email) — pengingat H-1 sebelum jadwal, reminder pengembalian, notifikasi approval ke atasan.
5. **Manajemen Denda Non-Finansial** — mis. penangguhan hak pinjam sementara bagi peminjam yang telat mengembalikan, sebagai alternatif/tambahan dari denda uang.
6. **Multi-tenant per Fakultas/Unit** — tiap fakultas/unit bisa punya aset dan pengelola sendiri, tapi tetap dalam satu sistem terpusat (mirip konsep "Cabang" di StarentCar, tapi berbasis struktur organisasi bukan geografis).

---

## 3. Lingkup Sistem (Scope)

### 3.1 Jenis Aset yang Dikelola
- Kendaraan dinas/operasional kampus
- Ruangan: kelas, aula, ruang rapat, ruang sidang skripsi, ruang serbaguna
- Peralatan: proyektor, sound system, kamera, laptop/tablet, alat laboratorium, meja-kursi lipat, tenda
- Fasilitas: lapangan olahraga, gedung olahraga, gedung pertemuan

### 3.2 Jenis Pengguna/Peminjam
- Mahasiswa (perorangan atau atas nama organisasi kemahasiswaan)
- Dosen & Staf
- Unit/Fakultas/Lembaga internal
- Pihak eksternal/umum (untuk skema penyewaan berbayar, jika kampus membuka fasilitas untuk umum)

### 3.3 Jenis Transaksi
- Peminjaman internal (gratis, butuh approval)
- Penyewaan (berbayar; internal dengan tarif subsidi, atau eksternal dengan tarif komersial)
- Peminjaman berulang/terjadwal (mis. ruang kelas rutin per semester)

### 3.4 Di Luar Lingkup (Fase Awal)
- Integrasi pembayaran otomatis via payment gateway (bisa masuk fase lanjutan)
- Integrasi dengan sistem akademik (SIAKAD) — direkomendasikan sebagai fase lanjutan, bukan MVP

---

## 4. Arsitektur Modul Sistem (Detail)

### A. Modul Master Data
1. Kategori Aset (Kendaraan, Ruangan, Alat, Fasilitas)
2. Jenis/Tipe Aset per kategori (atribut dinamis, mis. kendaraan punya plat nomor & kapasitas, ruangan punya kapasitas kursi & fasilitas AC/proyektor)
3. Data Aset (kode aset, kondisi, lokasi, status: tersedia/dipinjam/maintenance)
4. Lokasi/Gedung/Lantai
5. Fakultas/Unit Pemilik Aset
6. Data Peminjam (Mahasiswa, Dosen/Staf, Unit, Eksternal)
7. Jenis Pembayaran (untuk skema sewa)
8. Petugas/Operator Pendamping
9. Tempat & Keterangan Pemeliharaan

### B. Modul Transaksi
1. Pengajuan Peminjaman/Penyewaan (dengan pilihan tanggal & jam via kalender ketersediaan)
2. Approval Berjenjang (multi-level sesuai kebijakan unit)
3. Serah Terima Aset (checklist kondisi, foto, tanda tangan digital)
4. Pengembalian Aset (checklist kondisi, kalkulasi keterlambatan)
5. Piutang & Pembayaran Penyewaan (khusus transaksi berbayar)
6. Deposit/Jaminan (opsional)
7. Pemeliharaan Aset (jadwal servis rutin, riwayat perbaikan)

### C. Modul Keuangan & Akuntansi (Opsional, aktif untuk transaksi berbayar)
1. Kas/Bank Masuk-Keluar
2. Chart of Account, Jurnal Umum, Neraca, Tutup Buku
3. Laporan Keuangan Penyewaan

### D. Modul Laporan & Statistik
1. Dashboard utilisasi aset (real-time)
2. Laporan rekap & detail peminjaman/penyewaan per kategori/unit/periode
3. Laporan aset yang sering dipinjam / jarang dipakai (utilization rate)
4. Laporan keterlambatan & pelanggaran
5. Laporan piutang & keuangan (jika ada skema berbayar)

### E. Modul Notifikasi & Pengaturan
1. Notifikasi WhatsApp/Email (pengingat, status approval, reminder pengembalian)
2. Manajemen User & Hak Akses (role: Admin Pusat, Admin Unit/Fakultas, Approver, Peminjam)
3. Pengaturan Situs/Perusahaan (identitas kampus, unit, dsb.)

---

## 5. Rancangan Peran & Hak Akses (Role-Based Access)

| Role | Hak Akses |
|---|---|
| Super Admin (BMN/Rumah Tangga Pusat) | Akses penuh ke semua modul & unit |
| Admin Unit/Fakultas | Kelola aset & transaksi milik unitnya saja |
| Approver (Kaprodi/Kepala Unit) | Menyetujui/menolak pengajuan dari unitnya |
| Petugas Serah Terima | Input serah terima & pengembalian aset |
| Peminjam (Mahasiswa/Dosen/Staf/Eksternal) | Mengajukan peminjaman/penyewaan, melihat status & riwayat sendiri |
| Bagian Keuangan | Akses modul keuangan & piutang penyewaan |

---

## 6. Tahapan Implementasi

### Fase 0 — Persiapan (2–3 minggu)
- Workshop kebutuhan dengan pihak kampus (bagian umum/rumah tangga, keuangan, fakultas percontohan)
- Inventarisasi aset & kategori awal
- Penetapan kebijakan: aset mana yang gratis, mana yang berbayar; alur approval per unit

### Fase 1 — Desain (3–4 minggu)
- Desain ERD/database (generalisasi dari struktur StarentCar)
- Desain wireframe modul inti: Master Data, Pengajuan, Approval, Kalender Ketersediaan
- Desain alur approval & notifikasi

### Fase 2 — Pengembangan MVP (6–8 minggu)
- Modul Master Data (Aset, Lokasi, Peminjam)
- Modul Pengajuan Peminjaman + Kalender Ketersediaan
- Modul Approval Berjenjang
- Modul Serah Terima & Pengembalian
- Dashboard dasar

### Fase 3 — Modul Penyewaan & Keuangan (4–6 minggu)
- Modul Penyewaan berbayar (piutang, pembayaran, deposit)
- Modul Keuangan & Akuntansi (opsional/aktif sesuai kebutuhan)
- Laporan keuangan

### Fase 4 — Modul Lanjutan (4–6 minggu)
- Notifikasi WA/Email otomatis
- Laporan & statistik utilisasi lanjutan
- Modul pemeliharaan aset

### Fase 5 — UAT, Pelatihan & Go-Live (3–4 minggu)
- User Acceptance Testing dengan unit percontohan
- Pelatihan admin unit & approver
- Migrasi data aset awal
- Go-live bertahap (pilot 1–2 fakultas → seluruh kampus)

### Fase 6 — Pemeliharaan & Pengembangan Lanjutan
- Integrasi payment gateway (jika diperlukan)
- Integrasi dengan SIAKAD/SSO kampus
- Aplikasi mobile untuk pengajuan cepat

---

## 7. Estimasi Timeline Keseluruhan

Total estimasi: **± 22–31 minggu (5–7 bulan)** dari persiapan hingga go-live penuh, tergantung kompleksitas jumlah unit/fakultas yang dilibatkan dan tingkat kustomisasi approval per unit.

---

## 8. Kebutuhan Tim

- 1 Project Manager
- 1–2 Backend Developer
- 1 Frontend Developer
- 1 UI/UX Designer
- 1 QA/Tester
- 1 Business Analyst (penghubung dengan pihak kampus untuk pemetaan kebijakan approval & tarif)

---

## 9. Risiko & Mitigasi

| Risiko | Mitigasi |
|---|---|
| Beragamnya kebijakan approval antar fakultas | Buat sistem approval yang **konfigurabel** per unit, bukan hard-code |
| Data aset awal tidak lengkap/akurat | Lakukan sesi inventarisasi aset sebelum migrasi data |
| Resistensi pengguna (dosen/staf) terhadap sistem baru | Pilot di 1–2 unit dulu, sediakan pelatihan & panduan |
| Bentrok jadwal ruangan akibat data lama (manual) | Wajibkan migrasi jadwal existing ke kalender sistem sebelum go-live |
| Kompleksitas skema gratis vs berbayar tercampur | Pisahkan secara jelas di level kategori aset & alur transaksi sejak desain awal |

---

## 10. Modul Tambahan — Pelacakan & Akuntabilitas Aset

1. **Integrasi/Kompatibilitas dengan SIMAK-BMN** (untuk kampus negeri) — data aset perlu bisa diekspor atau disinkronkan ke format yang kompatibel dengan pelaporan Barang Milik Negara.
2. **Depresiasi/Penyusutan Aset** — pencatatan nilai buku dan penyusutan aset dari waktu ke waktu, bukan hanya status ketersediaan.
3. **QR Code/Barcode per Aset** — ditempel di fisik aset dan dipindai saat proses serah terima & pengembalian untuk mempercepat proses dan mengurangi kesalahan input manual.
4. **Audit Trail/Log Aktivitas** — mencatat siapa mengubah, menyetujui, atau menolak apa dan kapan; penting untuk pertanggungjawaban aset milik institusi.
5. **Tanda Tangan Digital** saat serah terima & pengembalian, sebagai pelengkap checklist kondisi dan dokumentasi foto.

## 11. Modul Tambahan — Alur Bisnis & Kebijakan Peminjaman

1. **Sistem Antrian (Waiting List)** — jika aset/ruangan sedang dipakai, peminjam otomatis masuk antrian dan mendapat notifikasi begitu aset tersedia kembali.
2. **Prioritas Penggunaan** — kegiatan akademik (kelas, ujian) otomatis diprioritaskan dibanding kegiatan non-akademik saat terjadi konflik jadwal.
3. **Booking Berulang/Batch** — mendukung kebutuhan rutin semesteran (mis. ruang kelas dipakai tiap Senin jam tertentu selama satu semester) tanpa harus input satu per satu.
4. **Blacklist/Penangguhan Otomatis** — peminjam yang berulang kali telat mengembalikan atau merusak aset akan otomatis ditangguhkan hak pinjamnya oleh sistem, tanpa perlu intervensi manual admin.
5. **Sinkronisasi dengan Kalender Akademik** — periode ujian atau libur kampus otomatis memblokir slot pemesanan pada kalender ketersediaan.

## 12. Modul Tambahan — Pengalaman Pengguna & Aksesibilitas

1. **Rating/Feedback Pasca-Pemakaian** — peminjam menilai kondisi aset, dan admin dapat menilai kedisiplinan peminjam.
2. **Aplikasi Mobile / Web Responsif** — memungkinkan pengajuan peminjaman dari perangkat mobile tanpa harus membuka versi desktop.
3. **Self-Service Status Tracking** — peminjam dapat memantau progres approval secara real-time tanpa perlu menghubungi admin secara manual.

## 13. Modul Tambahan — Keamanan, Kepatuhan & Infrastruktur

1. **Kepatuhan terhadap UU PDP** — mengingat sistem menyimpan data pribadi (NIM, NIP, nomor HP), diperlukan kebijakan privasi dan keamanan data yang jelas serta terdokumentasi.
2. **Rencana Backup & Disaster Recovery** — penting karena sistem menyangkut aset milik institusi dan data transaksi yang harus dapat dipertanggungjawabkan.
3. **API Terbuka** — mendukung integrasi di masa depan dengan SIAKAD, SSO kampus, atau sistem keuangan lain.
4. **Change Management Plan** — mencakup sosialisasi dan SOP transisi dari sistem manual (Excel/pencatatan per unit) ke sistem baru, karena resistensi perubahan sering menjadi titik gagal implementasi meskipun sistemnya sudah baik secara teknis.

## 14. Catatan Penting

Dokumen ini adalah **kerangka perencanaan awal (blueprint)**, bukan spesifikasi teknis final. Sebelum masuk ke tahap pengembangan, disarankan untuk:
1. Melakukan workshop kebutuhan detail dengan pihak kampus terkait (bagian rumah tangga, keuangan, dan minimal 2 fakultas percontohan).
2. Menentukan struktur organisasi kampus secara pasti untuk pemetaan modul "Fakultas/Unit".
3. Menyepakati kebijakan mana yang gratis (peminjaman) dan mana yang berbayar (penyewaan), termasuk untuk siapa saja (internal/eksternal).