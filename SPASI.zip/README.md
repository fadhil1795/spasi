# 🏢 SPASI — Sistem Pencatatan Aset, Sewa & Pinjam Instansi

SPASI adalah platform manajemen aset fisik, peminjaman sarana internal, dan penyewaan ruangan & peralatan terintegrasi berbasis **Next.js 14**, **TypeScript**, **Tailwind/Vanilla CSS**, **Prisma ORM**, dan **MySQL Database**.

---

## ✨ Fitur Utama

1. **Dashboard & Katalog Aset Fisik**
   - Pencatatan aset per kategori, departemen, dan lokasi.
   - Perhitungan penyusutan nilai aset otomatis per tahun.
   - Peminjaman barang internal dengan alur persetujuan berjenjang (Level 1 & Level 2).
   - Cetak label QR Code untuk pelabelan aset fisik.

2. **Modul Sewa Ruangan & Inventaris Terintegrasi (Traveloka-Style)**
   - **Penyewaan Ruangan Publik (`/rooms`)**: Katalog ruangan dengan filter fasilitas, luas, dan kapasitas.
   - **Kalkulator & Pengecekan Ketersediaan Pintar**: Sistem Anti-Double Booking yang memeriksa waktu sewa secara real-time.
   - **Peralatan Tambahan (Add-On Assets)**: Sewa peralatan tambahan (proyektor, sound system, laptop, kamera) dalam 1 alur pemesanan.
   - **E-Voucher & QR Code**: Tiket digital penyewa dilengkapi QR Code unik untuk validasi lokasi.
   - **Inspeksi Check-In & Check-Out**: Pencatatan otomatis kondisi barang bawaan ruangan (`isFixedToRoom`) dan alat add-on saat penyerahan & pengembalian.
   - **Klaim Kerusakan/Kehilangan**: Perhitungan otomatis denda/klaim yang dipotong dari deposit jaminan jika terdapat kerusakan barang.

3. **Scanner QR Code Petugas (`/dashboard/room-bookings/scan`)**
   - Pemindaian QR Code E-Voucher penyewa melalui kamera WebRTC atau pencarian manual nomor booking.

---

## 🛠️ Prasyarat & Teknologi

- **Node.js**: `v22.x`
- **Database**: MySQL `8.x` / MariaDB (Database: `spasi_db`)
- **Framework**: Next.js 14 (App Router), React 18, TypeScript
- **ORM**: Prisma v5

---

## 🚀 Panduan Instalasi & Memulai

### 1. Clone & Install Dependensi
```bash
npm install
```

### 2. Konfigurasi Environment (`.env`)
Buat file `.env` di root direktori dengan kredensial MySQL Anda:
```env
DATABASE_URL="mysql://root:123@localhost:3306/spasi_db"
NEXTAUTH_SECRET="spasi-super-secret-key-2026"
NEXTAUTH_URL="http://localhost:3000"
```

### 3. Setup Database MySQL
Buat database di MySQL server:
```sql
CREATE DATABASE spasi_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

Jalankan push schema dan seed data awal:
```bash
npx prisma db push
npx prisma generate
npx prisma db seed
```

### 4. Jalankan Server Dev
```bash
npm run dev
```
Akses di browser:
- **Katalog Publik Ruangan**: [http://localhost:3000/rooms](http://localhost:3000/rooms)
- **Dashboard Admin**: [http://localhost:3000/dashboard](http://localhost:3000/dashboard) (Login: `admin@spasi.id` / `admin123`)

---

## 📚 Dokumentasi Modul

Detail arsitektur teknis dan skema tabel dapat dibaca pada file berikut:
- 📄 [Dokumentasi Fitur Sewa Ruangan](docs/FITUR_SEWA_RUANGAN.md)
- 📄 [Dokumentasi Desain & Arsitektur](docs/desain.md)
- 📄 [Requirements Spesifikasi](docs/requirements.md)

---

© SPASI Platform Team — Built for Institutional Asset & Facility Management.
